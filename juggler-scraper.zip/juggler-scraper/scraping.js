import puppeteer from 'puppeteer-extra';
import StealthPlugin from 'puppeteer-extra-plugin-stealth';
import { createClient } from '@supabase/supabase-js';

puppeteer.use(StealthPlugin());

const proxy = process.env.PROXY_SERVER || '';
const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_KEY);

// --- 4 machine URLs (replace with real URLs if変更する場合あり) ---
const MACHINE_URLS = [
  { name: 'アイムTP',     url: 'https://meruhenworld.pt.teramoba2.com/ashikaga/standlist_slot/?kind_code=2127&machine_name=S%25EF%25BD%25B1%25EF%25BD%25B2%25EF%25BE%2591%25EF%25BD%25BC%25EF%25BE%259E%25EF%25BD%25AC%25EF%25BD%25B8%25EF%25BE%259E%25EF%25BE%2597%25E3%2583%25BCEX%25E2%2588%2592TP&list_kind=day' },
  { name: 'マイV',        url: 'https://meruhenworld.pt.teramoba2.com/ashikaga/standlist_slot/?kind_code=2127&machine_name=S%25EF%25BE%258F%25EF%25BD%25B2%25EF%25BD%25BC%25EF%25BE%259E%25EF%25BD%25AC%25EF%25BD%25B8%25EF%25BE%259E%25EF%25BE%2597%25E3%2583%25BCVKD&list_kind=day' },
  { name: 'ハッピーV3',   url: 'https://meruhenworld.pt.teramoba2.com/ashikaga/standlist_slot/?kind_code=2127&machine_name=S%25EF%25BE%258A%25EF%25BD%25AF%25EF%25BE%258B%25EF%25BE%259F%25E3%2583%25BC%25EF%25BD%25BC%25EF%25BE%259E%25EF%25BD%25AC%25EF%25BD%25B8%25EF%25BE%259E%25EF%25BE%2597%25E3%2583%25BCV%2BIII%2BEA&list_kind=day' },
  { name: 'ゴーゴー3',     url: 'https://meruhenworld.pt.teramoba2.com/ashikaga/standlist_slot/?kind_code=2127&machine_name=S%25EF%25BD%25BA%25EF%25BE%259E%25EF%25BD%25B0%25EF%25BD%25BA%25EF%25BE%259E%25EF%25BD%25B0%25EF%25BD%25BC%25EF%25BE%259E%25EF%25BD%25AC%25EF%25BD%25B8%25EF%25BE%259E%25EF%25BE%2597%25EF%25BD%25B03KA&list_kind=day' }
];

(async () => {
  const browser = await puppeteer.launch({
    headless: 'new',
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      proxy && `--proxy-server=${proxy}`
    ].filter(Boolean)
  });

  const page = await browser.newPage();
  await page.setUserAgent(
    'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148'
  );

  const today = new Date().toISOString().slice(0, 10); // YYYY-MM-DD

  for (const m of MACHINE_URLS) {
    await page.goto(m.url, { waitUntil: 'networkidle2', timeout: 0 }).catch(console.error);

    const rows = await page.$$eval('table.tbl_data01 tr', trs =>
      trs.slice(1).map(tr => {
        const tds = [...tr.querySelectorAll('td')].map(td => td.innerText.trim());
        return {
          number: parseInt(tds[0], 10) || null,
          big:    parseInt(tds[1], 10) || 0,
          reg:    parseInt(tds[2], 10) || 0,
          spins:  parseInt(tds[3].replace(/,/g, ''), 10) || 0
        };
      })
    );

    for (const r of rows) {
      if (!r.number) continue;

      const totalBonus = r.big + r.reg;
      const combined   = totalBonus ? (r.spins / totalBonus) : null;
      const regProb    = r.reg ? (r.spins / r.reg) : null;

      // --- very simple expectation calc ---
      let expect6 = 0;
      if (regProb && regProb < 270 && r.spins > 2000) expect6 = 0.8;
      else if (regProb && regProb < 300)             expect6 = 0.5;

      await supabase.from('juggler_history').insert({
        date: today,
        machine: m.name,
        number: r.number,
        big: r.big,
        reg: r.reg,
        spins: r.spins,
        combined,
        reg_prob: regProb,
        expect6
      });
    }
    console.log(m.name + ' done');
  }

  await browser.close();
})();
